package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.model.Driver;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Long> {

	@Query(value="SELECT * from Driver where city=city", nativeQuery=true)
	List<Driver> findByCity( String city);
	
	@Query(value="select * from Driver where telephonenumber =:telephonenumber and engineSize >=:engineSize",nativeQuery=true)
	Driver findByEngine(long telephonenumber,int engineSize);
}
