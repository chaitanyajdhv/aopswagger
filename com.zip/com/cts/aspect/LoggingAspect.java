package com.cts.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


//@Aspect
//@Component
//public class LoggingAspect {
//	private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);
//
//	@Before("execution(* com.cts.service.*(..))")
//	public void logBefore(JoinPoint joinPoint)
//	{
//		logger.info("Before Method Called :: "+ joinPoint.getSignature().getName());
//		System.out.println("Before Method Called :: "+ joinPoint.getSignature().getName());
//	}
//	
//	@Around("execution(* com.cts.service.*(..))")
//	public void logAround(JoinPoint joinPoint)
//	{
//		System.out.println("Around Method Called :: "+ joinPoint.getSignature().getName());
//	}
//	
//	
//	@After("execution(* com.cts.service.*.*(..))")
//	public void logAfter(JoinPoint joinPoint)
//	{
//		logger.info("After Method Called :: "+ joinPoint.getSignature().getName());
//		System.out.println("After Method Called :: "+ joinPoint.getSignature().getName());
//	}
//
//	
//	
//	@AfterReturning(pointcut= "execution(* com.cts.service.*.*(..))",returning="result")
//	public void logAfterReturning(JoinPoint joinPoint,Object result)
//	{
//		System.out.println("Capturing Method Return Value :: "+ joinPoint.getSignature().getName()+" -- Result is "+result);
//	}
//	
//	@AfterThrowing(pointcut= "execution(* com.cts.service.*.*(..))",throwing="expObj")
//	public void logAfterThrowing(JoinPoint joinPoint,Exception expObj)
//	{
//		logger.info("Capturing Method Exception :: "+ joinPoint.getSignature().getName()+" -- Exception Is "+expObj);
//		System.out.println("Capturing Method Exception :: "+ joinPoint.getSignature().getName()+" -- Exception Is "+expObj);
//	}
//}
