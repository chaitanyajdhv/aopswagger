package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.DriverAlreadyExists;
import com.cts.exception.DriverIdNotFoundException;
import com.cts.model.Driver;
import com.cts.repository.DriverRepository;

import jakarta.validation.Valid;

@Service
public class DriverServiceImpl implements DriverService{

	@Autowired
	private DriverRepository driverRepository;
	
	@Override
	public Driver saveDriver(@Valid Driver driver) {
		System.out.println("driver data :: "+driver);
			Optional<Driver> d_Duplicate= driverRepository.findById(driver.getDriverId());
			if (!d_Duplicate.isPresent()) {
				return driverRepository.save(driver);

			}
			else {
				throw new DriverAlreadyExists("already exists");
			}
		
		// TODO Auto-generated method stub
	}

	@Override
	public List<Driver> getAllDriver() {
		// TODO Auto-generated method stub
		return driverRepository.findAll();
	}
//throws Exception
	@Override
	public Driver updateDriver(@Valid Driver driver,Long id)  {
		// TODO Auto-generated method stub
		if(driverRepository.findById(id).isPresent()) {
		Driver driver1=driverRepository.findById(id).get();

		driver1.setFirstName(driver.getFirstName());
		return driverRepository.save(driver1);
		}
		else {
			throw new DriverIdNotFoundException("not found for update");
		}
		
	}
//throws Exception 
	@Override
	public String deleteDriver(@Valid Long id) {
		// TODO Auto-generated method stub
		Optional<Driver> s =driverRepository.findById(id);
		if(s.isPresent()) {
		 driverRepository.deleteById(id);
			return "ID deleted";

		 }
		else {
			throw new DriverIdNotFoundException("ID not found for deletion");
		}
	}

	@Override
	public List<Driver> findByCity(String city) {
		// TODO Auto-generated method stub
		return driverRepository.findByCity(city);
	}

	@Override
	public Optional<Driver> findByEngine(long telephonenumber, int engineSize) {
		// TODO Auto-generated method stub
		System.out.println("tele is "+telephonenumber +" : "+"engineSize is : "+engineSize );
		driverRepository.findByEngine(telephonenumber, engineSize);
		Optional<Driver> optionald=Optional.ofNullable( driverRepository.findByEngine(telephonenumber, engineSize));
		return optionald.isPresent()?optionald:optionald.empty();
	}

}
