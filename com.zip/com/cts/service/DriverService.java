package com.cts.service;

import java.util.List;
import java.util.Optional;

import com.cts.model.Driver;

public interface DriverService {

	public Driver saveDriver(Driver driver) ;
	public List<Driver> getAllDriver();
	public Driver updateDriver(Driver driver,Long id) ; //throws Exception
	public String deleteDriver(Long id) ; //throws Exception
	public List<Driver> findByCity(String city);
	public Optional<Driver> findByEngine(long telephonenumber, int engineSize);
}
