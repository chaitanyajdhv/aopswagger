package com.cts.model;

import org.antlr.v4.runtime.misc.NotNull;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
public class Driver {

	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
	private long driverId;
	@NotBlank(message = "firstName must not be blank")
	private String firstName;
	//@Max(value = 2, message = "telephonenumber must be max 10")

	@Min(value = 1000000000L, message = "Mobile number must be at least 10 digits.")
	private long telephonenumber;
	@NotBlank(message = "address must not be blank")
	private String address;
	@NotBlank(message = "city must not be blank")
	private String city;
	@jakarta.validation.constraints.NotNull(message = "engineSize must not be blank")
	private int engineSize;
	@Min(value = 1000, message = "quoteAmount must be at least 1000")
	private long quoteAmount;
	
//	public Driver() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public Driver(long driverId, String firstName, long telephonenumber, String address, String city, int engineSize,
//			long quoteAmount) {
//		super();
//		this.driverId = driverId;
//		this.firstName = firstName;
//		this.telephonenumber = telephonenumber;
//		this.address = address;
//		this.city = city;
//		this.engineSize = engineSize;
//		this.quoteAmount = quoteAmount;
//	}

	public long getDriverId() {
		return driverId;
	}

	public void setDriverId(long driverId) {
		this.driverId = driverId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public long getTelephonenumber() {
		return telephonenumber;
	}

	public void setTelephonenumber(long telephonenumber) {
		this.telephonenumber = telephonenumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getEngineSize() {
		return engineSize;
	}

	public void setEngineSize(int engineSize) {
		this.engineSize = engineSize;
	}

	public long getQuoteAmount() {
		return quoteAmount;
	}

	public void setQuoteAmount(long quoteAmount) {
		this.quoteAmount = quoteAmount;
	}

	@Override
	public String toString() {
		return "Driver [driverId=" + driverId + ", firstName=" + firstName + ", telephonenumber=" + telephonenumber
				+ ", address=" + address + ", city=" + city + ", engineSize=" + engineSize + ", quoteAmount="
				+ quoteAmount + "]";
	}
	
}
