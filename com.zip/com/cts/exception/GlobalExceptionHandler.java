package com.cts.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	 @ExceptionHandler(ConstraintViolationException.class)
	    public ResponseEntity<String> handleValidationExceptions(ConstraintViolationException ex) {
	        StringBuilder message = new StringBuilder();
	        ex.getConstraintViolations().forEach(violation -> message.append(violation.getMessage()).append("\n"));
	        return new ResponseEntity<>(message.toString(), HttpStatus.BAD_REQUEST);
	    }
	 
	 @ExceptionHandler(DriverIdNotFoundException.class)
	    public ResponseEntity<String> handleValidationExceptionDriverNotFound(DriverIdNotFoundException ex) {
	        StringBuilder message = new StringBuilder();
	        return new ResponseEntity<>(ex.toString(), HttpStatus.BAD_REQUEST);
	    }
	 @ExceptionHandler(DriverAlreadyExists.class)
	    public ResponseEntity<String> handleValidationExceptionDriverAlreadyExits(DriverAlreadyExists ex) {
	        StringBuilder message = new StringBuilder();
	        return new ResponseEntity<>(ex.toString(), HttpStatus.BAD_REQUEST);
	    }
}
