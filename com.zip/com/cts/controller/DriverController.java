package com.cts.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.exception.DriverAlreadyExists;
import com.cts.exception.DriverIdNotFoundException;
import com.cts.model.Driver;
import com.cts.service.DriverService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class DriverController {

	@Autowired
	private DriverService driverService;
	
	@PostMapping("/save")
	public ResponseEntity<?> saveDriver(@Valid @RequestBody Driver driver) {
	//	try {
		return new ResponseEntity<>(driverService.saveDriver(driver),HttpStatus.OK);
		//}
	//	catch(DriverAlreadyExists e) {
	//		return new ResponseEntity<>("Driver already exists",HttpStatus.NOT_FOUND);
	//	}
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<Driver>> getAllDriver(){
		return new ResponseEntity<List<Driver>>( driverService.getAllDriver(),HttpStatus.OK);
	}
	//throws Exception
	@PutMapping("/update")
	public ResponseEntity<?> updateDriver( @Valid @RequestBody Driver driver,@RequestParam long id) {
	//	try {
		return new ResponseEntity<Driver>(driverService.updateDriver(driver, id),HttpStatus.OK);
		//}
		//catch(DriverIdNotFoundException e) {
			//return new ResponseEntity<>("Driver not found",HttpStatus.NOT_FOUND);

		//}
		}
	// throws Exception
	@DeleteMapping("/deleteid/{id}")
	public String deleteDriver(@Valid @PathVariable("id") Long id) {
	//	try {
		return driverService.deleteDriver(id);
		//}
		//catch(DriverIdNotFoundException e) {
			//return "Driver not found";
		//}
		
	}
	
	@GetMapping("/findbycity")
	public ResponseEntity<List<Driver>> findByCity(@RequestParam String city){
		 return new ResponseEntity<List<Driver>>(driverService.findByCity(city),HttpStatus.OK);
	}
	
	@GetMapping("/byengine")
	public Optional<Driver> findByEngine(@RequestParam long telephonenumber,@RequestParam int engineSize){
		return driverService.findByEngine(telephonenumber, engineSize);
	}
}
